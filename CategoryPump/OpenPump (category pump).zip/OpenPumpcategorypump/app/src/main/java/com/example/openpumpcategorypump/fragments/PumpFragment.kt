package com.example.openpumpcategorypump.fragments

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.openpumpcategorypump.R
import com.example.openpumpcategorypump.api.ApiInterface
import com.example.openpumpcategorypump.dialogs_fragments.PumpInfoDialog
import org.json.JSONObject
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.net.URL

class PumpFragment : Fragment() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_pump, container, false)
        getMyData()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        var vote_button: ImageView = view.findViewById(R.id.btn_vote_for_pump)
        var question_button: ImageView = view.findViewById(R.id.icon_question)

        question_button.setOnClickListener {
            showDialog()
        }
        vote_button.setOnClickListener {
            Toast.makeText(context?.applicationContext, "Clicked Vote", Toast.LENGTH_SHORT).show()

        }
    }

    fun showDialog() {
        val dialogFragment = PumpInfoDialog()
        val manager = fragmentManager
        dialogFragment.show(manager!!, "dialog_pump_info")
    }

    private fun getData(){
        var BASE_URL = "https://api.coingecko.com/api/v3/"
        val retrofitBuilder = Retrofit.Builder()
            .addConverterFactory(GsonConverterFactory.create())
            .baseUrl(BASE_URL)
            .build()
            .create(ApiInterface::class.java)
    }

    private fun getMyData(){
        val url = "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=100&page=1&sparkline=false"
        val apiResponse = URL(url).readText()
        val coin_info = JSONObject(apiResponse).getJSONArray("")
        Log.d("INFO", apiResponse)
    }
}